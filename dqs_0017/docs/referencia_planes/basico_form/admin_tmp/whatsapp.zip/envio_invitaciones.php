<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Token y URL de WhatsApp API
$token = 'EAAPA9jgbdsQBPNfCnJCLhcz6f65R0LT7uPJJ8uQBh0zVKnEZAsoES6huVgbSZBktyNCTaWqTCp0XlxuCcaSqzJyvyw1E8aBKw4FVEZCyAllCTB4O5L9E1r7SEsLeCjf0qKL6Fffx4PJiaD8WbqveiGrV9yGBfbw49CZACrcGeTm8LScH0Sj8jBNyVLNBvDdfPZAFL7jGI7AZDZD';
$url = 'https://graph.facebook.com/v22.0/717330018120745/messages';

// Conexión MySQL
$servername = "127.0.0.1";
$username = "u385461681_admin";
$password = "Curuzu.1810";
$dbname = "u385461681_regalo_casorio";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Consulta
$sql = "
SELECT 
    a.id,
    a.codigo,
    a.apellido,
    a.nombre,
    e.invitados,
    b.categoria_acompanante acompanado,
    a.cantidad_mayores,
    a.cantidad_menores,
    a.ingreso,
    f.categoria_prioridad,
    g.tel_enviar,
    a.confirmacion,
    a.confirmacion_fecha,
    a.alimento,
    a.confirmacion_comentario alimento_comentario,
    a.confirmacion_mayores,
    a.confirmacion_menores,
    a.activo
FROM invitados a
LEFT JOIN intivados_acompanante b ON a.acompanado = b.id
LEFT JOIN (
    SELECT 
        a.id_invitados,
        CASE WHEN cantidad_mayores+cantidad_menores<2 THEN nombre_invitado ELSE 
        CONCAT(
            IF(COUNT(*) > 1,
                SUBSTRING_INDEX(GROUP_CONCAT(nombre_invitado ORDER BY a.id ASC SEPARATOR ', '), ', ', COUNT(*) - 1),
                GROUP_CONCAT(nombre_invitado ORDER BY a.id ASC SEPARATOR ', ')
            ),
            ' y ',
            SUBSTRING_INDEX(GROUP_CONCAT(nombre_invitado ORDER BY a.id ASC SEPARATOR ', '), ', ', -1)
        ) END AS invitados
    FROM invitados_listado_mesa a
    INNER JOIN invitados b ON a.id_invitados=b.id
    GROUP BY a.id_invitados
) e ON a.id = e.id_invitados
LEFT JOIN invitados_prioridad f ON a.id_prioridad = f.id
LEFT JOIN (
    SELECT id_invitados, tel_enviar
    FROM invitados_tel
) g ON a.id = g.id_invitados
LEFT JOIN invitaciones_estado i ON a.id = i.id_invitado
WHERE a.activo = 1 AND i.id_invitado IS NULL
AND tel_enviar IN (1131648789,9999999999)
ORDER BY Apellido, Nombre
LIMIT 20
;
";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $id = $row["id"];
        $nombre = $row["nombre"];
        $apellido = $row["apellido"];
        $ingreso = $row["ingreso"];
        $telefono = "54" . $row["tel_enviar"];
        $imagen_nombre = str_pad($id, 4, "0", STR_PAD_LEFT) . ".jpg";
        $imagen_url = "https://rdpcompraventa.com/regalos_casamiento_v2/adminA0KxlHeVGc/invitaciones/" . $imagen_nombre;
        $invitados = $row["invitados"];
        $codigo = $row["codigo"];       
        $link_dinamico = $row["codigo"] . "#rsvp";
   

        // Construir JSON con plantilla
        $data = [
            "messaging_product" => "whatsapp",
            "to" => $telefono,
            "type" => "template",
            "template" => [
                "name" => "plantilla_cliente_0002", // nombre exacto de tu plantilla
                "language" => [ "code" => "en_US" ],
                "components" => [
                    [
                        "type" => "header",
                        "parameters" => [
                            [
                                "type" => "image",
                                "image" => [
                                    "link" => $imagen_url
                                ]
                            ]
                        ]
                    ],
                    [
                        "type" => "body",
                        "parameters" => [
                            [
                                "type" => "text",
                                "text" => $invitados
                            ],
                            [
                                "type" => "text",
                                "text" => $codigo
                            ]
                        ]
                    ],
                    [
                        "type" => "button",
                        "sub_type" => "url",
                        "index" => "0",
                        "parameters" => [
                            [
                                "type" => "text",
                                "text" => $link_dinamico // Por ejemplo: código único del invitado
                            ]
                        ]
                    ]
                ]
            ]
        ];


        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        // Mostrar
        echo "ID: $id<br>";
        echo "Teléfono: $telefono<br>";
        echo "Imagen: $imagen_url<br>";
        echo "<pre>JSON enviado:\n$json</pre>";

        // Enviar por CURL
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Bearer $token",
            "Content-Type: application/json"
        ]);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);
        $status_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        echo "<pre>Respuesta API:\n$response</pre>";

        // Registrar resultado
        $estado = ($status_code == 200) ? 'enviado' : 'error';
        $fecha_envio = date('Y-m-d H:i:s');

        $stmt = $conn->prepare("INSERT INTO invitaciones_estado (id_invitado, fecha_envio, estado_api, detalle_api) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("isss", $id, $fecha_envio, $estado, $response);
        $stmt->execute();
        $stmt->close();

        sleep(1); // Pausa para evitar límite de velocidad
        echo "<hr>";
    }
} else {
    echo "No se encontraron registros pendientes de envío.";
}

$conn->close();
?>
